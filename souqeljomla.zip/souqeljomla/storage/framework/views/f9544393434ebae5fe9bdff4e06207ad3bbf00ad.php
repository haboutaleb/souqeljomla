<!DOCTYPE html>
<html lang="en">
<head>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Souq Eljonmla</title>
  <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet" type="text/css" />
  <link href="https://fonts.googleapis.com/css?family=Tajawal" rel="stylesheet">
<style>
body{
  font-family: 'Tajawal', sans-serif;

}
</style>
</head>
<body>
  <div class="container">
    <?php echo $__env->yieldContent('main'); ?>
  </div>
  <script src="<?php echo e(asset('js/app.js')); ?>" type="text/js"></script>
  <script src="<?php echo e(asset('jquery.min.js')); ?>"></script>
  <?php echo $__env->yieldContent('script'); ?>
  
</body>
</html><?php /**PATH /home/zsc/souqeljomla/resources/views/base.blade.php ENDPATH**/ ?>