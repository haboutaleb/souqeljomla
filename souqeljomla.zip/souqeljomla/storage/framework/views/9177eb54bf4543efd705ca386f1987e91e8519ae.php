<?php $__env->startSection('main'); ?>
<div class="row">
 <div class="col-sm-8 offset-sm-2">
    <h1 class="display-3  text-right">اضافة اسم</h1>
  <div>
    <?php if($errors->any()): ?>
      <div class="alert alert-danger">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
      </div><br />
    <?php endif; ?>
      <form method="post" action="<?php echo e(route('contacts.store')); ?>">
          <?php echo csrf_field(); ?>
          <div class="form-group  text-right">    
              <label for="name"> :الاسم</label>
              <input type="text" class="form-control  text-right" name="name"/>
          </div>

          <div class="form-group  text-right">
              <label for="phone"> :رقم الهاتف</label>
              <input type="text" class="form-control  text-right" name="phone"/>
          </div>

          <div class="form-group  text-right">
              <label for="job_title">:المسمي الوظيفي</label>
              <input type="text" class="form-control  text-right" name="job_title"/>
          </div>  
          
          <div class="form-group  text-right">
              <label for="email"> :الاميل</label>
              <input type="text" class="form-control  text-right" name="email"/>
          </div>
                       
          <button type="submit" class="btn btn-primary text-center float-right btn-block">اضافة</button>
      </form>
  </div>
</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/zsc/souqeljomla/resources/views/contacts/create.blade.php ENDPATH**/ ?>