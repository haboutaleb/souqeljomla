<?php $__env->startSection('main'); ?>
<div class="col-sm-12">

  <?php if(session()->get('success')): ?>
    <div class="alert alert-success">
      <?php echo e(session()->get('success')); ?>  
    </div>
  <?php endif; ?>
</div>



<div class="row">
<div class="col-sm-12">
    <h1 class="display-3 text-right ">البيانات</h1>  
    <div class= "container"> 


    <form> 
        <select name='type' id="search-type" class="form-control col-md-4 " style=" float: right;" >
            <option  value=''> طريقة البحث </option>
            <option value='ID'> الرقم التعريفي </option>
            <option value='Number'> رقم الهاتف </option>
            <option value='Name'> بالاسم </option>
        </select>

      <div class="form-group" id="search-input-div" style="margin-top: 25px;">
          <input class="form-control col-md-4" type="text" id="search-input"   style=" float: right; margin-right:7px;">
          <button class="btn btn-primary "  id="search-button"  style="margin: 19px;"> بحث </button>
      </div>
    </form>


    <a style="margin: 19px;" href="<?php echo e(route('contacts.create')); ?>" class="btn btn-primary">اضافة جديد</a>
</div>
<div class="container col-sm-12 text-right">    
  <table class="table table-striped col-sm-12 float-right table-responsive">
    <thead>
        <tr>
        <td colspan = 2>العمليات</td>

          <td class="d-none d-lg-block  text-right">المسمي الوظيفي</td>
          <td class="">الاسم</td>
          <td class="d-none d-lg-block">الاميل</td>

          <td>رقم التليفون</td>
          <td>الرقم التعريفي</td>
        </tr>
    </thead>
    <tbody id="table-result">
        <?php $__currentLoopData = $contacts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $contact): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
        <td>
                <a href="<?php echo e(route('contacts.edit',$contact->id)); ?>" class="btn btn-primary">تعديل</a>
            </td>
            <td>
                <form action="<?php echo e(route('contacts.destroy', $contact->id)); ?>" method="post">
                  <?php echo csrf_field(); ?>
                  <?php echo method_field('DELETE'); ?>
                  <button class="btn btn-danger" type="submit">حذف</button>
                </form>
            </td>
            <td class="d-none d-lg-block"><?php echo e($contact->job_title); ?></td>
            <td><?php echo e($contact->name); ?></td>
            <td class="d-none d-lg-block"><?php echo e($contact->email); ?></td>

            <td><?php echo e($contact->phone); ?></td>
            <td><?php echo e($contact->id); ?></td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
  </table>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
  <script>
  $(document).ready(function(){
    
    $('#search-input-div').hide()
   
    $('#search-type').on('change',function(){
        $('#search-input-div').show()
      });

     $('#search-button').on('click',function(event){
      event.preventDefault()  ;
      var type =   $('#search-type').val();
      var data =   $('#search-input').val();

      if( type !='' && data != ''){
        $.ajax({
          type:"GET",
          url:"/contacnts/search",
          dataType:'json',
          data:{type:type,data:data},
          success: function (response) {
            // alert(response);
            $('#table-result').html("")

            console.log(response);
            if(response.contacts.length>0){
              $.each(response.contacts, function(i, item){
              var $tr = $('<tr>').append(
                $('<td>').text(""),

                // $('<td>').append($("<a href="<?php echo e(route('contacts.edit',$contact->id)); ?>" class="btn btn-primary">تعديل</a>")),
                $('<td "><a href="<?php echo e(route('contacts.edit',$contact->id)); ?>" class="btn btn-primary">تعديل</a>'),
                $('<td class="d-none d-lg-block">').text(item.job_title),
                $('<td>').text(item.name),
                $('<td class="d-none d-lg-block"> ').text(item.email),

                $('<td>').text(item.phone),
                $('<td>').text(item.id),
                // $('<td>').html"( <button class="btn btn-danger" type="submit">Delete</button>)"
              )
              $('#table-result').append($tr)
            });

            }else{
              
              var $tr = $('<tr>').append(
                $('<th colspan="5">').text(response.message),
              )  
              $('#table-result').append($tr) ;
            }
            
          },
          error:function(err){
            console.log(err);
          }
        });
      }
     }); 
  }) 
    
  </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/zsc/souqeljomla/resources/views/contacts/index.blade.php ENDPATH**/ ?>